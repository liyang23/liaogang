# 辽港伐谋知识管理平台 - API接口定义

> **文档编号**：API-2026-001
> **版本**：v1.0
> **基于**：PRD-2026-001 v0.20 + 原型 V3.0
> **架构模式**：前后端分离（RESTful API）
> **最后更新**：2026-06-15
> **接口数量**：45个

---

## 一、认证与用户

### 用户登录

**接口路径**: `POST /auth/login`

**功能描述**: 用户登录/SSO认证，返回JWT令牌

**请求参数** (application/json):

| 字段 | 类型 | 必填 | 说明 | 规则 |
|------|------|------|------|------|
| username | string | ✅ | 用户名 | 4-32字符 |
| password | string | ✅ | 密码 | 6-128字符 |

**请求示例**:
```json
{
  "username": "admin",
  "password": "encrypted_password"
}
```

**响应参数**:

| 字段 | 类型 | 说明 |
|------|------|------|
| token | string | JWT 访问令牌 |
| refreshToken | string | 刷新令牌 |
| expiresIn | int | 令牌过期时间(秒) |
| user | object | 用户信息 |

**user 对象**:

| 字段 | 类型 | 说明 |
|------|------|------|
| userId | string | 用户ID (USR-XXXX) |
| username | string | 用户名 |
| nickname | string | 昵称 |
| email | string | 邮箱 |
| avatar | string | 头像URL |
| roles | array | 角色列表 |

**响应示例** (成功):
```json
{
  "code": 200,
  "message": "登录成功",
  "data": {
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "expiresIn": 7200,
    "user": {
      "userId": "USR-0001",
      "username": "admin",
      "nickname": "管理员",
      "email": "admin@liaogang.com",
      "avatar": "https://example.com/avatar/1.png",
      "roles": ["ROLE-0001"]
    }
  },
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

**响应示例** (失败):
```json
{
  "code": 401,
  "message": "用户名或密码错误",
  "data": null,
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

**错误码说明**:

| code | message | 说明 |
|------|---------|------|
| 200 | 登录成功 | - |
| 400 | 参数校验失败 | 请求参数格式错误 |
| 401 | 用户名或密码错误 | 认证失败 |
| 403 | 账号已被禁用 | 账户状态异常 |
| 429 | 操作过于频繁 | 限流 |
| 500 | 服务器内部错误 | - |

---

### 获取当前用户信息

**接口路径**: `GET /auth/current-user`

**功能描述**: 获取当前用户信息及完整权限体系（含项目级菜单权限矩阵）

**请求头**:

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| Authorization | string | ✅ | Bearer Token |

**响应参数**:

| 字段 | 类型 | 说明 |
|------|------|------|
| userId | string | 用户ID |
| username | string | 用户名 |
| nickname | string | 昵称 |
| email | string | 邮箱 |
| avatar | string | 头像URL |
| roles | array | 平台角色列表 |
| projects | array | 有权限的项目列表 |

**platformRoles item 结构**:

| 字段 | 类型 | 说明 |
|------|------|------|
| roleId | string | 角色ID |
| name | string | 角色名称 |

**projects item 结构**:

| 字段 | 类型 | 说明 |
|------|------|------|
| projectId | string | 项目ID (PROJ-XXXX) |
| name | string | 项目名称 |
| role | string | 项目内角色 (ADMIN/EDITOR/VIEWER) |
| permissions | object | 项目内菜单权限矩阵 |

**permissions 结构** (项目级菜单权限矩阵):

| 字段 | 类型 | 说明 |
|------|------|------|
| DASHBOARD | object | 总览仪表盘权限 |
| KO_LIBRARY | object | 知识对象库权限 |
| KO_CON | object | 约束类KO权限 |
| KO_RUL | object | 规则类KO权限 |
| KO_PAR | object | 参数类KO权限 |
| KO_ONT | object | 本体类KO权限 |
| KO_PRM | object | 提示词模板类KO权限 |
| KO_DOC | object | 文档类KO权限 |
| PROMPT | object | 提示词权限 |
| GOVERNANCE | object | 知识治理权限 |
| AUDIT_LOG | object | 审计日志权限 |
| PROJECT | object | 项目管理权限 |
| DICTIONARY | object | 字典管理权限 |
| PERMISSION | object | 权限与角色权限 |

**menuPermission 结构** (每个菜单项的权限对象):

| 字段 | 类型 | 说明 |
|------|------|------|
| view | boolean | 查阅权限 |
| create | boolean | 新增权限 |
| update | boolean | 更新权限 |
| delete | boolean | 删除权限 |
| audit | boolean | 审核权限 |

**响应示例**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "userId": "USR-0001",
    "username": "admin",
    "nickname": "管理员",
    "email": "admin@liaogang.com",
    "avatar": "https://example.com/avatar/1.png",
    "platformRoles": [
      { "roleId": "ROLE-0001", "name": "系统管理员" }
    ],
    "projects": [
      {
        "projectId": "PROJ-0001",
        "name": "辽港一期",
        "role": "ADMIN",
        "permissions": {
          "DASHBOARD": { "view": true, "create": true, "update": true, "delete": true, "audit": false },
          "KO_LIBRARY": { "view": true, "create": true, "update": true, "delete": true, "audit": true },
          "KO_CON": { "view": true, "create": true, "update": true, "delete": true, "audit": true },
          "KO_RUL": { "view": true, "create": true, "update": true, "delete": true, "audit": true },
          "KO_PAR": { "view": true, "create": true, "update": true, "delete": true, "audit": true },
          "KO_ONT": { "view": true, "create": true, "update": true, "delete": true, "audit": true },
          "KO_PRM": { "view": true, "create": true, "update": true, "delete": true, "audit": true },
          "KO_DOC": { "view": true, "create": true, "update": true, "delete": true, "audit": true },
          "PROMPT": { "view": true, "create": true, "update": true, "delete": true, "audit": false },
          "GOVERNANCE": { "view": true, "create": true, "update": true, "delete": true, "audit": true },
          "AUDIT_LOG": { "view": true, "create": true, "update": true, "delete": true, "audit": true },
          "PROJECT": { "view": true, "create": true, "update": true, "delete": true, "audit": true },
          "DICTIONARY": { "view": true, "create": true, "update": true, "delete": true, "audit": true },
          "PERMISSION": { "view": true, "create": true, "update": true, "delete": true, "audit": true }
        }
      },
      {
        "projectId": "PROJ-0002",
        "name": "辽港二期",
        "role": "EDITOR",
        "permissions": {
          "DASHBOARD": { "view": true, "create": false, "update": false, "delete": false, "audit": false },
          "KO_LIBRARY": { "view": true, "create": true, "update": true, "delete": false, "audit": false },
          "KO_CON": { "view": true, "create": true, "update": true, "delete": false, "audit": false },
          "KO_RUL": { "view": true, "create": true, "update": true, "delete": false, "audit": false },
          "KO_PAR": { "view": true, "create": true, "update": true, "delete": false, "audit": false },
          "KO_ONT": { "view": true, "create": false, "update": false, "delete": false, "audit": false },
          "KO_PRM": { "view": true, "create": false, "update": false, "delete": false, "audit": false },
          "KO_DOC": { "view": true, "create": false, "update": false, "delete": false, "audit": false },
          "PROMPT": { "view": true, "create": true, "update": true, "delete": false, "audit": false },
          "GOVERNANCE": { "view": true, "create": false, "update": false, "delete": false, "audit": false },
          "AUDIT_LOG": { "view": true, "create": false, "update": false, "delete": false, "audit": false },
          "PROJECT": { "view": true, "create": false, "update": false, "delete": false, "audit": false },
          "DICTIONARY": { "view": true, "create": false, "update": false, "delete": false, "audit": false },
          "PERMISSION": { "view": true, "create": false, "update": false, "delete": false, "audit": false }
        }
      }
    ]
  },
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

**权限矩阵说明**:

每个项目的 `permissions` 对象定义了用户在该项目下的菜单级权限。权限粒度：

| 操作 | 说明 | 适用场景 |
|------|------|----------|
| view | 查阅 | 查看列表、详情、搜索 |
| create | 新增 | 新建知识对象、新建提示词等 |
| update | 更新 | 编辑知识对象、修改参数等 |
| delete | 删除 | 删除知识对象、删除提示词等 |
| audit | 审核 | 审核通过/驳回知识对象修改 |

**菜单项编码对照**:

| 编码 | 菜单名称 | 说明 |
|------|----------|------|
| DASHBOARD | 总览仪表盘 | 仪表盘统计和活动列表 |
| KO_LIBRARY | 知识对象库 | 知识对象库入口(含6个子类型) |
| KO_CON | 约束 | 约束类知识对象 |
| KO_RUL | 规则 | 规则类知识对象 |
| KO_PAR | 参数 | 参数类知识对象 |
| KO_ONT | 本体 | 本体类知识对象 |
| KO_PRM | 提示词模板 | 提示词模板类知识对象 |
| KO_DOC | 文档 | 文档类知识对象 |
| PROMPT | 提示词 | 提示词列表、组装器、快照 |
| GOVERNANCE | 知识治理 | C类冲突和H类健康问题 |
| AUDIT_LOG | 审计日志 | 操作审计记录 |
| PROJECT | 项目管理 | 项目创建、成员管理 |
| DICTIONARY | 字典管理 | 类型介绍、效力分级、权威分级等 |
| PERMISSION | 权限与角色 | 角色管理和用户角色分配 |

---

## 二、总览仪表盘

### 获取统计数据

**接口路径**: `GET /dashboard/stats`

**功能描述**: 获取统计数据（KO总数、已生效数、待治理项）

**请求参数** (Query):

| 字段 | 类型 | 必填 | 说明 | 默认值 |
|------|------|------|------|--------|
| projectId | string | ❌ | 项目ID | 当前项目 |

**响应参数**:

| 字段 | 类型 | 说明 |
|------|------|------|
| totalKoCount | int | KO总数 |
| activeKoCount | int | 已生效KO数 |
| activeKoRate | double | 生效率(%) |
| pendingGovernanceCount | int | 待处置治理项数 |
| typeDistribution | object | 各类型KO数量分布 |
| conflictDistribution | object | 冲突类型分布 |
| trend | object | 环比变化趋势 |

**typeDistribution 结构**:

| 字段 | 类型 | 说明 |
|------|------|------|
| CON | int | 约束类数量 |
| RUL | int | 规则类数量 |
| PAR | int | 参数类数量 |
| ONT | int | 本体类数量 |
| PRM | int | 提示词模板类数量 |
| DOC | int | 文档类数量 |

**trend 结构**:

| 字段 | 类型 | 说明 |
|------|------|------|
| koTrend | string | KO变化趋势 (↑/↓/-) |
| activeTrend | string | 生效KO变化趋势 |
| governanceTrend | string | 治理项变化趋势 |

**响应示例**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "totalKoCount": 277,
    "activeKoCount": 267,
    "activeKoRate": 96.4,
    "pendingGovernanceCount": 13,
    "typeDistribution": {
      "CON": 18,
      "RUL": 47,
      "PAR": 89,
      "ONT": 41,
      "PRM": 12,
      "DOC": 70
    },
    "conflictDistribution": {
      "C1": 2,
      "C2": 6,
      "C3": 1,
      "C4": 2,
      "C6": 1,
      "H2": 1
    },
    "trend": {
      "koTrend": "↑3",
      "activeTrend": "↑1",
      "governanceTrend": "↓2"
    }
  },
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

### 获取最近活动

**接口路径**: `GET /dashboard/activities`

**功能描述**: 获取最近10条知识对象活动动态

**请求参数** (Query):

| 字段 | 类型 | 必填 | 说明 | 默认值 |
|------|------|------|------|--------|
| limit | int | ❌ | 返回条数 | 10 |

**响应参数**:

| 字段 | 类型 | 说明 |
|------|------|------|
| list | array | 活动列表 |

**list item 结构**:

| 字段 | 类型 | 说明 |
|------|------|------|
| activityId | long | 活动ID |
| koId | string | KO ID |
| koType | string | KO类型 |
| operateType | string | 操作类型 |
| operator | object | 操作人信息 |
| description | string | 操作描述 |
| createTime | string | 操作时间 |

**operator 结构**:

| 字段 | 类型 | 说明 |
|------|------|------|
| userId | string | 用户ID |
| username | string | 用户名 |
| nickname | string | 昵称 |

**响应示例**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "list": [
      {
        "activityId": 1001,
        "koId": "KO-CON-0015",
        "koType": "CON",
        "operateType": "CREATE",
        "operator": {
          "userId": "USR-0001",
          "username": "admin",
          "nickname": "管理员"
        },
        "description": "创建约束 KO-CON-0015",
        "createTime": "2024-06-14 10:30:00"
      },
      {
        "activityId": 1002,
        "koId": "KO-PAR-0045",
        "koType": "PAR",
        "operateType": "UPDATE",
        "operator": {
          "userId": "USR-0003",
          "username": "expert01",
          "nickname": "业务专家"
        },
        "description": "修改参数值: 3.5 → 4.0",
        "createTime": "2024-06-14 09:15:00"
      }
    ]
  },
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

## 三、知识对象库

### 获取KO全景概览

**接口路径**: `GET /ko/library`

**功能描述**: 获取KO全景概览（6类型入口卡片、统计数据）

**请求参数** (Query):

| 字段 | 类型 | 必填 | 说明 | 默认值 |
|------|------|------|------|--------|
| projectId | string | ❌ | 项目ID | 当前项目 |

**响应参数**:

| 字段 | 类型 | 说明 |
|------|------|------|
| totalKoCount | int | KO总数 |
| activeKoCount | int | 已生效数 |
| stats | object | 全库统计 |
| typeCards | array | 类型入口卡片 |

**stats 结构**:

| 字段 | 类型 | 说明 |
|------|------|------|
| activeCount | int | 活跃数 |
| referenceCount | int | 引用关系数 |
| pendingGovernance | int | 未处置治理项 |

**typeCards item 结构**:

| 字段 | 类型 | 说明 |
|------|------|------|
| type | string | 类型代码 |
| typeName | string | 类型中文名 |
| description | string | 一句话描述 |
| color | string | 类型颜色 |
| count | int | KO数量 |
| activeCount | int | 已生效数 |

**响应示例**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "totalKoCount": 277,
    "activeKoCount": 267,
    "stats": {
      "activeCount": 267,
      "referenceCount": 152,
      "pendingGovernance": 13
    },
    "typeCards": [
      {
        "type": "CON",
        "typeName": "约束",
        "description": "算法必须满足的边界条件",
        "color": "#C53030",
        "count": 18,
        "activeCount": 12
      },
      {
        "type": "RUL",
        "typeName": "规则",
        "description": "编码调度经验的If-Then启发式规则",
        "color": "#ED8936",
        "count": 47,
        "activeCount": 22
      },
      {
        "type": "PAR",
        "typeName": "参数",
        "description": "可调数值(权重、阈值、成本系数等)",
        "color": "#2F855A",
        "count": 89,
        "activeCount": 45
      },
      {
        "type": "ONT",
        "typeName": "本体",
        "description": "数据结构与业务概念定义",
        "color": "#6B46C1",
        "count": 41,
        "activeCount": 42
      },
      {
        "type": "PRM",
        "typeName": "提示词模板",
        "description": "含{{variable}}槽位的可复用提示词骨架",
        "color": "#97266D",
        "count": 12,
        "activeCount": 12
      },
      {
        "type": "DOC",
        "typeName": "文档",
        "description": "非结构化原始资料(PDF/Word/Excel)",
        "color": "#2D3748",
        "count": 70,
        "activeCount": 7
      }
    ]
  },
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

### 获取KO列表

**接口路径**: `GET /ko/{type}/list`

**功能描述**: 获取KO列表（支持分页、筛选、搜索）

**路径参数**:

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| type | string | ✅ | KO类型 (CON/RUL/PAR/ONT/PRM/DOC) |

**请求参数** (Query):

| 字段 | 类型 | 必填 | 说明 | 默认值 |
|------|------|------|------|--------|
| projectId | string | ❌ | 项目ID | 当前项目 |
| page | int | ❌ | 页码 | 1 |
| size | int | ❌ | 每页条数 | 10 |
| keyword | string | ❌ | 关键词搜索 | - |
| status | string | ❌ | 状态 | - |
| forceLevel | string | ❌ | 效力分级 | - |
| authorityLevel | string | ❌ | 权威分级 | - |
| groupName | string | ❌ | 分组名称 | - |
| sort | string | ❌ | 排序字段 | createTime |
| order | string | ❌ | 排序方向 | desc |

**响应参数**:

| 字段 | 类型 | 说明 |
|------|------|------|
| list | array | KO列表 |
| pagination | object | 分页信息 |

**list item 结构** (约束类 CON):

| 字段 | 类型 | 说明 |
|------|------|------|
| koId | string | KO ID |
| title | string | 标题 |
| forceLevel | string | 效力分级 |
| authorityLevel | string | 权威分级 |
| formalDefinition | string | 形式化定义 |
| keyParameters | array | 关键参数引用 |
| version | string | 版本号 |
| referenceCount | int | 引用计数 |
| status | string | 状态 |
| createTime | string | 创建时间 |

**list item 结构** (规则类 RUL):

| 字段 | 类型 | 说明 |
|------|------|------|
| koId | string | KO ID |
| title | string | 标题 |
| subRuleCount | int | 子规则数 |
| forceLevel | string | 效力分级 |
| authorityLevel | string | 权威分级 |
| coreRuleSummary | string | 核心规则摘要 |
| source | string | 来源 |
| version | string | 版本号 |
| referenceCount | int | 引用计数 |
| status | string | 状态 |
| createTime | string | 创建时间 |

**list item 结构** (参数类 PAR):

| 字段 | 类型 | 说明 |
|------|------|------|
| koId | string | KO ID |
| title | string | 参数名 |
| groupName | string | 分组 |
| symbol | string | 符号 |
| currentValue | string | 当前值 |
| dimension | string | 量纲 |
| valueRange | string | 取值范围 |
| version | string | 版本号 |
| referenceCount | int | 引用计数 |
| status | string | 状态 |
| createTime | string | 创建时间 |

**list item 结构** (本体类 ONT):

| 字段 | 类型 | 说明 |
|------|------|------|
| koId | string | KO ID |
| title | string | 名称 |
| type | string | 类型 |
| fieldCount | int | 字段数 |
| keyFields | string | 关键字段 |
| primaryKey | string | 主键 |
| version | string | 版本号 |
| referenceCount | int | 引用计数 |
| status | string | 状态 |
| createTime | string | 创建时间 |

**list item 结构** (提示词模板类 PRM):

| 字段 | 类型 | 说明 |
|------|------|------|
| koId | string | KO ID |
| title | string | 模板名 |
| type | string | 类型 |
| charCount | int | 字符数 |
| variableCount | int | 变量数 |
| usage | string | 用途 |
| version | string | 版本号 |
| referenceCount | int | 引用计数 |
| status | string | 状态 |
| createTime | string | 创建时间 |

**list item 结构** (文档类 DOC):

| 字段 | 类型 | 说明 |
|------|------|------|
| koId | string | KO ID |
| title | string | 文档名 |
| authorityLevel | string | 权威分级 |
| fileType | string | 文件格式 |
| fileSize | long | 文件大小 |
| uploader | object | 上传人 |
| updateTime | string | 更新时间 |
| status | string | 状态 |

**pagination 结构**:

| 字段 | 类型 | 说明 |
|------|------|------|
| page | int | 当前页码 |
| size | int | 每页条数 |
| total | int | 总条数 |
| totalPages | int | 总页数 |

**响应示例**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "list": [
      {
        "koId": "KO-CON-0015",
        "title": "岸桥最大作业量约束",
        "forceLevel": "Hard",
        "authorityLevel": "L2",
        "formalDefinition": "QC_i ≤ QC_max ∀i∈C",
        "keyParameters": ["KO-PAR-0001", "KO-PAR-0002"],
        "version": "v1.2.0",
        "referenceCount": 8,
        "status": "PUBLISHED",
        "createTime": "2024-01-15 10:30:00"
      }
    ],
    "pagination": {
      "page": 1,
      "size": 10,
      "total": 18,
      "totalPages": 2
    }
  },
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

### 获取KO详情

**接口路径**: `GET /ko/{koId}`

**功能描述**: 获取KO详情

**路径参数**:

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| koId | string | ✅ | KO ID |

**响应参数**:

| 字段 | 类型 | 说明 |
|------|------|------|
| koId | string | KO ID |
| type | string | 类型 |
| title | string | 标题 |
| summary | string | 摘要 |
| status | string | 状态 |
| forceLevel | string | 效力分级 |
| authorityLevel | string | 权威分级 |
| version | string | 版本号 |
| groupName | string | 分组名称 |
| author | object | 作者信息 |
| viewCount | int | 浏览次数 |
| referenceCount | int | 引用计数 |
| createTime | string | 创建时间 |
| updateTime | string | 更新时间 |
| publishTime | string | 发布时间 |
| typeData | object | 类型特定数据 |
| upstreamReferences | array | 上游引用 |
| downstreamReferences | array | 下游引用 |
| relatedPrompts | array | 关联提示词 |
| conflictBadge | object | 冲突徽章 |

**author 结构**:

| 字段 | 类型 | 说明 |
|------|------|------|
| userId | string | 用户ID |
| username | string | 用户名 |
| nickname | string | 昵称 |

**typeData 结构** (约束类):

| 字段 | 类型 | 说明 |
|------|------|------|
| formalDefinition | string | 形式化定义 |
| scope | string | 作用域 |
| keyParameters | array | 关键参数引用 |
| mathematicalExpressions | array | 数学表达式列表 |

**typeData 结构** (规则类):

| 字段 | 类型 | 说明 |
|------|------|------|
| conditionFormat | string | 条件格式 (IF-THEN) |
| subRules | array | 子规则列表 |
| priority | int | 优先级 |

**typeData 结构** (参数类):

| 字段 | 类型 | 说明 |
|------|------|------|
| symbol | string | 符号 |
| currentValue | string | 当前值 |
| dimension | object | 量纲信息 |
| valueRange | object | 取值范围 |
| oldValue | string | 旧值 (待审核时) |

**typeData 结构** (本体类):

| 字段 | 类型 | 说明 |
|------|------|------|
| schemaType | string | Schema类型 |
| fields | array | 字段定义列表 |
| primaryKey | string | 主键 |

**typeData 结构** (提示词模板类):

| 字段 | 类型 | 说明 |
|------|------|------|
| templateContent | string | 模板源码 |
| variables | array | 变量列表 |
| format | string | 格式 (FIXED/DYNAMIC) |

**typeData 结构** (文档类):

| 字段 | 类型 | 说明 |
|------|------|------|
| fileName | string | 文件名 |
| fileUrl | string | 文件URL |
| fileSize | long | 文件大小 |
| fileType | string | 文件类型 |

**conflictBadge 结构**:

| 字段 | 类型 | 说明 |
|------|------|------|
| level | string | 级别 (HIGH/MEDIUM/LOW) |
| count | int | 冲突数量 |
| conflicts | array | 冲突列表 |

**响应示例**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "koId": "KO-CON-0015",
    "type": "CON",
    "title": "岸桥最大作业量约束",
    "summary": "规定每台岸桥的最大小时作业量",
    "status": "PUBLISHED",
    "forceLevel": "Hard",
    "authorityLevel": "L2",
    "version": "v1.2.0",
    "groupName": "Hard",
    "author": {
      "userId": "USR-0001",
      "username": "admin",
      "nickname": "管理员"
    },
    "viewCount": 156,
    "referenceCount": 8,
    "createTime": "2024-01-15 10:30:00",
    "updateTime": "2024-06-10 14:20:00",
    "publishTime": "2024-01-16 09:00:00",
    "typeData": {
      "formalDefinition": "QC_i ≤ QC_max ∀i∈C",
      "scope": "所有岸桥",
      "keyParameters": [
        { "koId": "KO-PAR-0001", "name": "岸桥最大作业率" },
        { "koId": "KO-PAR-0002", "name": "岸桥效率系数" }
      ],
      "mathematicalExpressions": [
        { "expression": "QC_i ≤ QC_max", "description": "岸桥i作业量不超过最大值" }
      ]
    },
    "upstreamReferences": [
      { "koId": "KO-PAR-0001", "title": "岸桥最大作业率", "type": "PAR" }
    ],
    "downstreamReferences": [
      { "koId": "KO-PRM-0001", "title": "统筹模型主提示词", "type": "PRM" }
    ],
    "relatedPrompts": [
      { "promptId": "PRP-001", "name": "统筹模型主提示词", "snapshotId": "SNP-20260614-1430" }
    ],
    "conflictBadge": null
  },
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

### 创建知识对象

**接口路径**: `POST /ko`

**功能描述**: 创建知识对象

**请求参数** (application/json):

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| type | string | ✅ | KO类型 (CON/RUL/PAR/ONT/PRM/DOC) |
| title | string | ✅ | 标题 |
| summary | string | ❌ | 摘要 |
| forceLevel | string | ❌ | 效力分级 |
| authorityLevel | string | ❌ | 权威分级 |
| groupName | string | ❌ | 分组名称 |
| typeData | object | ❌ | 类型特定数据 |

**请求示例**:
```json
{
  "type": "CON",
  "title": "岸桥最大作业量约束",
  "summary": "规定每台岸桥的最大小时作业量",
  "forceLevel": "Hard",
  "authorityLevel": "L2",
  "groupName": "Hard",
  "typeData": {
    "formalDefinition": "QC_i ≤ QC_max ∀i∈C",
    "scope": "所有岸桥",
    "keyParameters": ["KO-PAR-0001", "KO-PAR-0002"]
  }
}
```

**响应参数**: 同获取KO详情接口

**响应示例**:
```json
{
  "code": 200,
  "message": "创建成功",
  "data": {
    "koId": "KO-CON-0016",
    "type": "CON",
    "title": "岸桥最大作业量约束",
    "status": "DRAFT",
    "version": "v1.0.0"
  },
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

### 编辑知识对象

**接口路径**: `PUT /ko/{koId}`

**功能描述**: 编辑知识对象

**路径参数**:

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| koId | string | ✅ | KO ID |

**请求参数** (application/json):

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| title | string | ❌ | 标题 |
| summary | string | ❌ | 摘要 |
| forceLevel | string | ❌ | 效力分级 |
| authorityLevel | string | ❌ | 权威分级 |
| groupName | string | ❌ | 分组名称 |
| typeData | object | ❌ | 类型特定数据 |

**响应参数**: 同获取KO详情接口

**响应示例**:
```json
{
  "code": 200,
  "message": "更新成功",
  "data": {
    "koId": "KO-CON-0015",
    "version": "v1.3.0"
  },
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

### 提交KO审核

**接口路径**: `POST /ko/{koId}/submit-review`

**功能描述**: 提交KO审核

**路径参数**:

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| koId | string | ✅ | KO ID |

**响应示例**:
```json
{
  "code": 200,
  "message": "提交成功",
  "data": null,
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

### 审核通过

**接口路径**: `POST /ko/{koId}/approve`

**功能描述**: 审核通过

**路径参数**:

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| koId | string | ✅ | KO ID |

**响应示例**:
```json
{
  "code": 200,
  "message": "审核通过",
  "data": null,
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

### 审核驳回

**接口路径**: `POST /ko/{koId}/reject`

**功能描述**: 审核驳回（需填写理由）

**路径参数**:

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| koId | string | ✅ | KO ID |

**请求参数** (application/json):

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| reason | string | ✅ | 驳回理由 |

**请求示例**:
```json
{
  "reason": "数值超出合理范围，请重新核算"
}
```

**响应示例**:
```json
{
  "code": 200,
  "message": "审核驳回",
  "data": null,
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

## 四、文档预览

### 获取文档文件

**接口路径**: `GET /ko/doc/{koId}/file`

**功能描述**: 获取文档文件（预览/下载）

**路径参数**:

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| koId | string | ✅ | KO ID |

**请求参数** (Query):

| 字段 | 类型 | 必填 | 说明 | 默认值 |
|------|------|------|------|--------|
| inline | boolean | ❌ | 是否inline预览 | false |

**响应头**:

| 字段 | 说明 |
|------|------|
| Content-Type | application/octet-stream 或对应 MIME 类型 |
| Content-Disposition | attachment; filename="xxx.pdf" 或 inline; filename="xxx.pdf" |
| Content-Length | 文件大小(字节) |
| X-File-Name | URL编码的原始文件名 |
| X-File-Size | 文件总大小 |

**响应示例** (文件下载):
```
HTTP/1.1 200 OK
Content-Type: application/pdf
Content-Disposition: attachment; filename="港口作业规范.pdf"
Content-Length: 2048576
X-File-Name: 港口作业规范.pdf
X-File-Size: 2048576

[binary file content]
```

**响应示例** (失败):
```json
{
  "code": 404,
  "message": "文件不存在或已过期",
  "data": null,
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

## 五、提示词

### 获取提示词列表

**接口路径**: `GET /prompts`

**功能描述**: 获取提示词列表

**请求参数** (Query):

| 字段 | 类型 | 必填 | 说明 | 默认值 |
|------|------|------|------|--------|
| page | int | ❌ | 页码 | 1 |
| size | int | ❌ | 每页条数 | 10 |
| keyword | string | ❌ | 关键词搜索 | - |
| status | string | ❌ | 状态 | - |
| boundAlgorithm | string | ❌ | 绑定算法 | - |

**响应参数**:

| 字段 | 类型 | 说明 |
|------|------|------|
| list | array | 提示词列表 |
| pagination | object | 分页信息 |

**list item 结构**:

| 字段 | 类型 | 说明 |
|------|------|------|
| promptId | string | 提示词ID |
| name | string | 提示词名称 |
| subtitle | string | 副标题 |
| version | string | 版本 |
| boundAlgorithm | string | 绑定算法 |
| koCount | int | 装配KO数 |
| snapshotVersion | string | 快照版本 |
| status | string | 状态 |
| format | string | 格式 |
| creator | object | 创建人 |
| createTime | string | 创建时间 |
| renderTime | string | 最近渲染时间 |

**响应示例**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "list": [
      {
        "promptId": "PRP-001",
        "name": "统筹模型主提示词",
        "subtitle": "72小时统筹优化",
        "version": "v3.0.0",
        "boundAlgorithm": "伐谋大模型",
        "koCount": 113,
        "snapshotVersion": "SNP-20260614-1430",
        "status": "PUBLISHED",
        "format": "FIXED+DYNAMIC",
        "creator": {
          "userId": "USR-0001",
          "username": "admin",
          "nickname": "管理员"
        },
        "createTime": "2024-01-10 09:00:00",
        "renderTime": "2024-06-14 14:30:00"
      }
    ],
    "pagination": {
      "page": 1,
      "size": 10,
      "total": 7,
      "totalPages": 1
    }
  },
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

### 获取提示词详情

**接口路径**: `GET /prompts/{promptId}`

**功能描述**: 获取提示词详情（含选中的KO）

**路径参数**:

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| promptId | string | ✅ | 提示词ID |

**响应参数**:

| 字段 | 类型 | 说明 |
|------|------|------|
| promptId | string | 提示词ID |
| name | string | 名称 |
| subtitle | string | 副标题 |
| version | string | 版本 |
| boundAlgorithm | string | 绑定算法 |
| status | string | 状态 |
| format | string | 格式 |
| creator | object | 创建人 |
| createTime | string | 创建时间 |
| updateTime | string | 更新时间 |
| selectedKos | array | 已选KO列表 |

**selectedKos item 结构**:

| 字段 | 类型 | 说明 |
|------|------|------|
| koId | string | KO ID |
| title | string | KO标题 |
| type | string | 类型 |
| section | string | 段落 (§1-§9) |
| mode | string | 模式 (FIXED/DYNAMIC) |
| displayOrder | int | 显示顺序 |

**响应示例**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "promptId": "PRP-001",
    "name": "统筹模型主提示词",
    "subtitle": "72小时统筹优化",
    "version": "v3.0.0",
    "boundAlgorithm": "伐谋大模型",
    "status": "PUBLISHED",
    "format": "FIXED+DYNAMIC",
    "creator": {
      "userId": "USR-0001",
      "username": "admin",
      "nickname": "管理员"
    },
    "createTime": "2024-01-10 09:00:00",
    "updateTime": "2024-06-14 14:30:00",
    "selectedKos": [
      {
        "koId": "KO-ONT-0001",
        "title": "船舶基础信息",
        "type": "ONT",
        "section": "§3",
        "mode": "DYNAMIC",
        "displayOrder": 1
      },
      {
        "koId": "KO-CON-0015",
        "title": "岸桥最大作业量约束",
        "type": "CON",
        "section": "§5",
        "mode": "DYNAMIC",
        "displayOrder": 2
      }
    ]
  },
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

### 新建提示词

**接口路径**: `POST /prompt`

**功能描述**: 新建提示词

**请求参数** (application/json):

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| name | string | ✅ | 名称 |
| subtitle | string | ❌ | 副标题 |
| boundAlgorithm | string | ❌ | 绑定算法 |
| format | string | ❌ | 格式 |
| selectedKos | array | ❌ | 已选KO列表 |

**响应参数**: 同获取提示词详情接口

**响应示例**:
```json
{
  "code": 200,
  "message": "创建成功",
  "data": {
    "promptId": "PRP-008",
    "name": "新提示词",
    "status": "DRAFT"
  },
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

### 编辑提示词

**接口路径**: `PUT /prompt/{promptId}`

**功能描述**: 编辑提示词（包含KO选择）

**路径参数**:

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| promptId | string | ✅ | 提示词ID |

**请求参数** (application/json):

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| name | string | ❌ | 名称 |
| subtitle | string | ❌ | 副标题 |
| boundAlgorithm | string | ❌ | 绑定算法 |
| format | string | ❌ | 格式 |
| selectedKos | array | ❌ | 已选KO列表 |

**响应参数**: 同获取提示词详情接口

**响应示例**:
```json
{
  "code": 200,
  "message": "更新成功",
  "data": {
    "promptId": "PRP-001",
    "version": "v3.1.0"
  },
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

### 渲染提示词

**接口路径**: `POST /prompt/{promptId}/render`

**功能描述**: 渲染提示词（含预检）

**路径参数**:

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| promptId | string | ✅ | 提示词ID |

**请求参数** (application/json):

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| selectedKos | array | ❌ | 已选KO列表（可选，覆盖已有的） |

**响应参数**:

| 字段 | 类型 | 说明 |
|------|------|------|
| content | string | 渲染后的提示词内容 |
| charCount | int | 字符数 |
| estimatedTokens | int | 估计Token数 |
| renderTime | long | 渲染耗时(ms) |
| hasConflicts | boolean | 是否有冲突 |
| conflicts | array | 冲突列表（有待处置时返回） |

**conflicts item 结构**:

| 字段 | 类型 | 说明 |
|------|------|------|
| conflictId | string | 冲突ID |
| type | string | 冲突类型 |
| level | string | 级别 |
| description | string | 描述 |
| koId1 | string | KO ID 1 |
| koId2 | string | KO ID 2 |
| suggestedStrategy | string | 建议处置策略 |

**响应示例** (无冲突):
```json
{
  "code": 200,
  "message": "渲染成功",
  "data": {
    "content": "【角色定义】\n你是港口调度算法工程师...\n【任务描述】\n72小时统筹任务...\n【输入数据】\n{{csv_schema_1}}...",
    "charCount": 4821,
    "estimatedTokens": 1205,
    "renderTime": 245,
    "hasConflicts": false,
    "conflicts": null
  },
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

**响应示例** (有待处置冲突):
```json
{
  "code": 200,
  "message": "渲染成功，但存在未处置冲突",
  "data": {
    "content": "...",
    "charCount": 4821,
    "estimatedTokens": 1205,
    "renderTime": 245,
    "hasConflicts": true,
    "conflicts": [
      {
        "conflictId": "CT-C1-20260614-0001",
        "type": "C1",
        "level": "HIGH",
        "description": "值冲突：KO-PAR-0001与KO-PAR-0015对同一参数声明不一致",
        "koId1": "KO-PAR-0001",
        "koId2": "KO-PAR-0015",
        "suggestedStrategy": "覆盖"
      }
    ]
  },
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

### 获取版本快照历史

**接口路径**: `GET /prompt/{promptId}/snapshots`

**功能描述**: 获取版本快照历史

**路径参数**:

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| promptId | string | ✅ | 提示词ID |

**响应参数**:

| 字段 | 类型 | 说明 |
|------|------|------|
| list | array | 快照列表 |

**list item 结构**:

| 字段 | 类型 | 说明 |
|------|------|------|
| snapshotId | string | 快照ID |
| version | string | 版本号 |
| promptContent | string | 提示词内容 |
| changeSummary | string | 变更摘要 |
| changeList | array | 变更清单 |
| author | object | 作者 |
| createTime | string | 创建时间 |

**changeList item 结构**:

| 字段 | 类型 | 说明 |
|------|------|------|
| action | string | 操作 (+/~/-) |
| koId | string | KO ID |
| title | string | KO标题 |
| type | string | 类型 |

**响应示例**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "list": [
      {
        "snapshotId": "SNP-20260614-1430",
        "version": "v3.0.0",
        "promptContent": "【角色定义】...",
        "changeSummary": "更新约束 KO-CON-0015，新增参数 KO-PAR-0045",
        "changeList": [
          { "action": "~", "koId": "KO-CON-0015", "title": "岸桥最大作业量约束", "type": "CON" },
          { "action": "+", "koId": "KO-PAR-0045", "title": "新参数", "type": "PAR" }
        ],
        "author": {
          "userId": "USR-0001",
          "username": "admin",
          "nickname": "管理员"
        },
        "createTime": "2024-06-14 14:30:00"
      },
      {
        "snapshotId": "SNP-20260610-0930",
        "version": "v2.9.0",
        "promptContent": "【角色定义】...",
        "changeSummary": "批量更新参数",
        "changeList": [
          { "action": "~", "koId": "KO-PAR-0001", "title": "岸桥最大作业率", "type": "PAR" }
        ],
        "author": {
          "userId": "USR-0003",
          "username": "expert01",
          "nickname": "业务专家"
        },
        "createTime": "2024-06-10 09:30:00"
      }
    ]
  },
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

### 创建快照

**接口路径**: `POST /prompt/{promptId}/snapshot`

**功能描述**: 创建快照

**路径参数**:

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| promptId | string | ✅ | 提示词ID |

**响应参数**:

| 字段 | 类型 | 说明 |
|------|------|------|
| snapshotId | string | 快照ID |
| version | string | 版本号 |
| createTime | string | 创建时间 |

**响应示例**:
```json
{
  "code": 200,
  "message": "快照创建成功",
  "data": {
    "snapshotId": "SNP-20260615-1530",
    "version": "v3.1.0",
    "createTime": "2024-06-15 15:30:00"
  },
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

## 六、知识治理

### 获取C类冲突列表

**接口路径**: `GET /governance/conflicts`

**功能描述**: 获取C类对象间冲突列表

**请求参数** (Query):

| 字段 | 类型 | 必填 | 说明 | 默认值 |
|------|------|------|------|--------|
| projectId | string | ❌ | 项目ID | 当前项目 |
| type | string | ❌ | 冲突类型 | - |
| level | string | ❌ | 级别 | - |

**响应参数**:

| 字段 | 类型 | 说明 |
|------|------|------|
| stats | object | 统计信息 |
| list | array | 冲突列表 |

**stats 结构**:

| 字段 | 类型 | 说明 |
|------|------|------|
| C1 | int | 值冲突数量 |
| C2 | int | 作用域重叠数量 |
| C3 | int | 依赖断裂数量 |
| C4 | int | 效力冲突数量 |
| C5 | int | 时序冲突数量 |
| C6 | int | 语义冲突数量 |

**list item 结构**:

| 字段 | 类型 | 说明 |
|------|------|------|
| conflictId | string | 冲突ID |
| type | string | 类型 |
| level | string | 级别 |
| description | string | 描述 |
| status | string | 状态 |
| ko1 | object | 冲突方1 |
| ko2 | object | 冲突方2 |
| suggestedStrategy | string | 建议策略 |
| createTime | string | 检测时间 |

**ko1/ko2 结构**:

| 字段 | 类型 | 说明 |
|------|------|------|
| koId | string | KO ID |
| title | string | 标题 |
| type | string | 类型 |
| value | string | 冲突值 |

**响应示例**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "stats": {
      "C1": 2,
      "C2": 6,
      "C3": 1,
      "C4": 2,
      "C5": 0,
      "C6": 1
    },
    "list": [
      {
        "conflictId": "CT-C1-20260614-0001",
        "type": "C1",
        "level": "HIGH",
        "description": "值冲突：同一参数声明不一致的数值",
        "status": "PENDING",
        "ko1": {
          "koId": "KO-PAR-0001",
          "title": "岸桥最大作业率",
          "type": "PAR",
          "value": "35"
        },
        "ko2": {
          "koId": "KO-PAR-0015",
          "title": "岸桥效率上限",
          "type": "PAR",
          "value": "40"
        },
        "suggestedStrategy": "覆盖",
        "createTime": "2024-06-14 10:00:00"
      }
    ]
  },
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

### 获取H类健康问题列表

**接口路径**: `GET /governance/health-issues`

**功能描述**: 获取H类自身健康问题列表

**请求参数** (Query):

| 字段 | 类型 | 必填 | 说明 | 默认值 |
|------|------|------|------|--------|
| projectId | string | ❌ | 项目ID | 当前项目 |
| type | string | ❌ | 问题类型 | - |

**响应参数**:

| 字段 | 类型 | 说明 |
|------|------|------|
| stats | object | 统计信息 |
| list | array | 问题列表 |

**stats 结构**:

| 字段 | 类型 | 说明 |
|------|------|------|
| H1 | int | 数据漂移数量（本期不实现） |
| H2 | int | 孤儿引用数量 |
| H3 | int | 长期停滞数量 |
| H4 | int | 引用失效数量 |

**list item 结构**:

| 字段 | 类型 | 说明 |
|------|------|------|
| issueId | string | 问题ID |
| type | string | 类型 |
| level | string | 级别 |
| description | string | 描述 |
| status | string | 状态 |
| ko | object | 涉及的KO |
| suggestedStrategy | string | 建议策略 |
| createTime | string | 检测时间 |

**ko 结构**:

| 字段 | 类型 | 说明 |
|------|------|------|
| koId | string | KO ID |
| title | string | 标题 |
| type | string | 类型 |

**响应示例**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "stats": {
      "H1": 0,
      "H2": 1,
      "H3": 0,
      "H4": 0
    },
    "list": [
      {
        "issueId": "CT-H2-20260614-0001",
        "type": "H2",
        "level": "LOW",
        "description": "孤儿引用：KO未被任何提示词或算法引用",
        "status": "PENDING",
        "ko": {
          "koId": "KO-CON-0018",
          "title": "历史约束",
          "type": "CON"
        },
        "suggestedStrategy": "标记废弃",
        "createTime": "2024-06-14 10:00:00"
      }
    ]
  },
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

### 处置冲突

**接口路径**: `POST /governance/conflict/{conflictId}/dispose`

**功能描述**: 处置冲突

**路径参数**:

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| conflictId | string | ✅ | 冲突ID |

**请求参数** (application/json):

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| strategy | string | ✅ | 处置策略 |
| notes | string | ❌ | 处置备注 |

**strategy 枚举值**:

| 值 | 说明 |
|------|------|
| 覆盖 | 以特例覆盖全局，或以全局覆盖特例 |
| 共存 | 保留两者，明确作用域区分 |
| 拆分 | 将一个KO拆分为多个独立KO |
| 暂缓 | 暂不处置，标记跟踪 |
| 忽略 | 标记为误报，不采取行动 |
| 标记废弃 | 标记KO为Deprecated状态 |

**响应示例**:
```json
{
  "code": 200,
  "message": "处置成功",
  "data": null,
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

## 七、项目管理

### 获取项目列表

**接口路径**: `GET /projects`

**功能描述**: 获取项目列表

**请求参数** (Query):

| 字段 | 类型 | 必填 | 说明 | 默认值 |
|------|------|------|------|--------|
| page | int | ❌ | 页码 | 1 |
| size | int | ❌ | 每页条数 | 10 |
| keyword | string | ❌ | 项目名称搜索 | - |
| status | string | ❌ | 状态 | - |

**响应参数**:

| 字段 | 类型 | 说明 |
|------|------|------|
| list | array | 项目列表 |
| pagination | object | 分页信息 |

**list item 结构**:

| 字段 | 类型 | 说明 |
|------|------|------|
| projectId | string | 项目ID |
| name | string | 项目名称 |
| description | string | 描述 |
| domain | string | 所属领域 |
| status | string | 状态 |
| koCount | int | KO数量 |
| memberCount | int | 成员数 |
| createTime | string | 创建时间 |

**响应示例**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "list": [
      {
        "projectId": "PROJ-0001",
        "name": "辽港一期",
        "description": "辽港港口调度优化项目",
        "domain": "港口调度",
        "status": "ACTIVE",
        "koCount": 277,
        "memberCount": 5,
        "createTime": "2024-01-01 09:00:00"
      }
    ],
    "pagination": {
      "page": 1,
      "size": 10,
      "total": 3,
      "totalPages": 1
    }
  },
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

### 创建项目

**接口路径**: `POST /project`

**功能描述**: 创建项目

**请求参数** (application/json):

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| name | string | ✅ | 项目名称 |
| description | string | ❌ | 描述 |
| domain | string | ❌ | 所属领域 |

**请求示例**:
```json
{
  "name": "辽港二期",
  "description": "辽港港口调度优化项目二期",
  "domain": "港口调度"
}
```

**响应参数**: 同获取项目详情接口

**响应示例**:
```json
{
  "code": 200,
  "message": "创建成功",
  "data": {
    "projectId": "PROJ-0004",
    "name": "辽港二期",
    "status": "ACTIVE"
  },
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

### 编辑项目信息

**接口路径**: `PUT /project/{projectId}`

**功能描述**: 编辑项目信息

**路径参数**:

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| projectId | string | ✅ | 项目ID |

**请求参数** (application/json):

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| name | string | ❌ | 项目名称 |
| description | string | ❌ | 描述 |
| domain | string | ❌ | 所属领域 |

**响应示例**:
```json
{
  "code": 200,
  "message": "更新成功",
  "data": {
    "projectId": "PROJ-0001",
    "name": "辽港一期(修订版)"
  },
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

### 获取项目详情

**接口路径**: `GET /project/{projectId}`

**功能描述**: 获取项目详情

**路径参数**:

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| projectId | string | ✅ | 项目ID |

**响应参数**:

| 字段 | 类型 | 说明 |
|------|------|------|
| projectId | string | 项目ID |
| name | string | 项目名称 |
| description | string | 描述 |
| domain | string | 所属领域 |
| status | string | 状态 |
| koCount | int | KO数量 |
| memberCount | int | 成员数 |
| createTime | string | 创建时间 |
| updateTime | string | 更新时间 |

**响应示例**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "projectId": "PROJ-0001",
    "name": "辽港一期",
    "description": "辽港港口调度优化项目",
    "domain": "港口调度",
    "status": "ACTIVE",
    "koCount": 277,
    "memberCount": 5,
    "createTime": "2024-01-01 09:00:00",
    "updateTime": "2024-06-14 10:00:00"
  },
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

### 归档项目

**接口路径**: `POST /project/{projectId}/archive`

**功能描述**: 归档项目

**路径参数**:

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| projectId | string | ✅ | 项目ID |

**响应示例**:
```json
{
  "code": 200,
  "message": "项目已归档",
  "data": null,
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

### 获取项目成员列表

**接口路径**: `GET /project/{projectId}/members`

**功能描述**: 获取项目成员列表

**路径参数**:

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| projectId | string | ✅ | 项目ID |

**响应参数**:

| 字段 | 类型 | 说明 |
|------|------|------|
| list | array | 成员列表 |

**list item 结构**:

| 字段 | 类型 | 说明 |
|------|------|------|
| userId | string | 用户ID |
| username | string | 用户名 |
| nickname | string | 昵称 |
| avatar | string | 头像 |
| role | string | 项目内角色 |
| joinTime | string | 加入时间 |

**响应示例**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "list": [
      {
        "userId": "USR-0001",
        "username": "admin",
        "nickname": "管理员",
        "avatar": "https://example.com/avatar/1.png",
        "role": "ADMIN",
        "joinTime": "2024-01-01 09:00:00"
      },
      {
        "userId": "USR-0003",
        "username": "expert01",
        "nickname": "业务专家",
        "avatar": "https://example.com/avatar/3.png",
        "role": "EDITOR",
        "joinTime": "2024-01-15 10:00:00"
      }
    ]
  },
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

### 添加项目成员

**接口路径**: `POST /project/{projectId}/member`

**功能描述**: 添加项目成员

**路径参数**:

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| projectId | string | ✅ | 项目ID |

**请求参数** (application/json):

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| userId | long | ✅ | 用户ID |
| role | string | ✅ | 项目内角色 |

**role 枚举值**:

| 值 | 说明 |
|------|------|
| ADMIN | 项目管理员 |
| EDITOR | 编辑者 |
| VIEWER | 只读观察者 |

**响应示例**:
```json
{
  "code": 200,
  "message": "成员添加成功",
  "data": null,
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

### 修改成员角色

**接口路径**: `PUT /project/{projectId}/member/{userId}`

**功能描述**: 修改成员角色

**路径参数**:

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| projectId | string | ✅ | 项目ID |
| userId | long | ✅ | 用户ID |

**请求参数** (application/json):

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| role | string | ✅ | 项目内角色 |

**响应示例**:
```json
{
  "code": 200,
  "message": "成员角色已更新",
  "data": null,
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

### 移除项目成员

**接口路径**: `DELETE /project/{projectId}/member/{userId}`

**功能描述**: 移除项目成员

**路径参数**:

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| projectId | string | ✅ | 项目ID |
| userId | long | ✅ | 用户ID |

**响应示例**:
```json
{
  "code": 200,
  "message": "成员已移除",
  "data": null,
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

## 八、字典管理

### 获取字典列表

**接口路径**: `GET /dictionary`

**功能描述**: 获取字典列表（支持type参数筛选）

**请求参数** (Query):

| 字段 | 类型 | 必填 | 说明 | 默认值 |
|------|------|------|------|--------|
| type | string | ❌ | 字典类型 | - |

**字典类型说明**:

| type | 说明 |
|------|------|
| TYPE_INTRO | 类型介绍 |
| FORCE | 效力分级 |
| AUTH | 权威分级 |
| GROUP | 类型分组名称 |
| CONCEPT | 知识对象概念 |
| DIMENSION | 量纲配置 |

**响应参数**:

| 字段 | 类型 | 说明 |
|------|------|------|
| list | array | 字典项列表 |

**list item 结构**:

| 字段 | 类型 | 说明 |
|------|------|------|
| dictId | string | 字典ID |
| category | string | 字典类型 |
| code | string | 字典项编码 |
| name | string | 名称 |
| description | string | 说明 |
| sortOrder | int | 排序 |
| extra | object | 扩展信息 |
| createTime | string | 创建时间 |

**响应示例**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "list": [
      {
        "dictId": "DICT-FORCE-Hard",
        "category": "FORCE",
        "code": "Hard",
        "name": "硬约束",
        "description": "算法必须满足的边界条件，违反即解非可行",
        "sortOrder": 1,
        "extra": null,
        "createTime": "2024-01-01 09:00:00"
      },
      {
        "dictId": "DICT-FORCE-Soft",
        "category": "FORCE",
        "code": "Soft",
        "name": "软约束",
        "description": "计入惩罚项的约束",
        "sortOrder": 2,
        "extra": null,
        "createTime": "2024-01-01 09:00:00"
      }
    ]
  },
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

### 新增字典项

**接口路径**: `POST /dictionary`

**功能描述**: 新增字典项

**请求参数** (application/json):

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| category | string | ✅ | 字典类型 |
| code | string | ✅ | 字典项编码 |
| name | string | ✅ | 名称 |
| description | string | ❌ | 说明 |
| sortOrder | int | ❌ | 排序 |
| extra | object | ❌ | 扩展信息 |

**请求示例**:
```json
{
  "category": "DIMENSION",
  "code": "BOX_PER_HOUR",
  "name": "箱/h",
  "description": "每小时箱量",
  "sortOrder": 10
}
```

**响应示例**:
```json
{
  "code": 200,
  "message": "创建成功",
  "data": {
    "dictId": "DICT-DIMENSION-BOX_PER_HOUR",
    "category": "DIMENSION",
    "code": "BOX_PER_HOUR",
    "name": "箱/h"
  },
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

### 编辑字典项

**接口路径**: `PUT /dictionary/{dictId}`

**功能描述**: 编辑字典项

**路径参数**:

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| dictId | string | ✅ | 字典ID |

**请求参数** (application/json):

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| name | string | ❌ | 名称 |
| description | string | ❌ | 说明 |
| sortOrder | int | ❌ | 排序 |
| extra | object | ❌ | 扩展信息 |

**响应示例**:
```json
{
  "code": 200,
  "message": "更新成功",
  "data": null,
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

### 删除字典项

**接口路径**: `DELETE /dictionary/{dictId}`

**功能描述**: 删除字典项

**路径参数**:

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| dictId | string | ✅ | 字典ID |

**响应示例**:
```json
{
  "code": 200,
  "message": "删除成功",
  "data": null,
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

## 九、权限与角色

### 获取角色列表

**接口路径**: `GET /roles`

**功能描述**: 获取角色列表

**响应参数**:

| 字段 | 类型 | 说明 |
|------|------|------|
| list | array | 角色列表 |

**list item 结构**:

| 字段 | 类型 | 说明 |
|------|------|------|
| roleId | string | 角色ID |
| name | string | 角色名称 |
| description | string | 描述 |
| isSystem | boolean | 是否系统预置 |
| userCount | int | 用户数 |
| permissions | array | 权限列表 |
| createTime | string | 创建时间 |

**permissions item 结构**:

| 字段 | 类型 | 说明 |
|------|------|------|
| menuCode | string | 菜单编码 |
| actions | array | 操作列表 |

**响应示例**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "list": [
      {
        "roleId": "ROLE-0001",
        "name": "系统管理员",
        "description": "系统预置管理员角色",
        "isSystem": true,
        "userCount": 2,
        "permissions": [
          { "menuCode": "DASHBOARD", "actions": ["VIEW", "CREATE", "UPDATE", "DELETE", "AUDIT"] },
          { "menuCode": "KO_LIBRARY", "actions": ["VIEW", "CREATE", "UPDATE", "DELETE", "AUDIT"] }
        ],
        "createTime": "2024-01-01 09:00:00"
      }
    ]
  },
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

### 创建角色

**接口路径**: `POST /role`

**功能描述**: 创建角色

**请求参数** (application/json):

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| name | string | ✅ | 角色名称 |
| description | string | ❌ | 描述 |
| permissions | array | ❌ | 权限列表 |

**请求示例**:
```json
{
  "name": "数据审核员",
  "description": "负责数据审核的角色",
  "permissions": [
    { "menuCode": "KO_LIBRARY", "actions": ["VIEW", "AUDIT"] },
    { "menuCode": "DASHBOARD", "actions": ["VIEW"] }
  ]
}
```

**响应示例**:
```json
{
  "code": 200,
  "message": "创建成功",
  "data": {
    "roleId": "ROLE-0005",
    "name": "数据审核员"
  },
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

### 编辑角色

**接口路径**: `PUT /role/{roleId}`

**功能描述**: 编辑角色

**路径参数**:

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| roleId | string | ✅ | 角色ID |

**请求参数** (application/json):

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| name | string | ❌ | 角色名称 |
| description | string | ❌ | 描述 |
| permissions | array | ❌ | 权限列表 |

**响应示例**:
```json
{
  "code": 200,
  "message": "更新成功",
  "data": null,
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

### 删除角色

**接口路径**: `DELETE /role/{roleId}`

**功能描述**: 删除角色

**路径参数**:

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| roleId | string | ✅ | 角色ID |

**响应示例**:
```json
{
  "code": 200,
  "message": "删除成功",
  "data": null,
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

**错误码说明**:

| code | message | 说明 |
|------|---------|------|
| 403 | 预置角色不可删除 | 系统预置角色不能删除 |

---

### 获取平台用户列表

**接口路径**: `GET /users`

**功能描述**: 获取平台用户列表

**请求参数** (Query):

| 字段 | 类型 | 必填 | 说明 | 默认值 |
|------|------|------|------|--------|
| page | int | ❌ | 页码 | 1 |
| size | int | ❌ | 每页条数 | 5 |
| keyword | string | ❌ | 用户名搜索 | - |

**响应参数**:

| 字段 | 类型 | 说明 |
|------|------|------|
| list | array | 用户列表 |
| pagination | object | 分页信息 |

**list item 结构**:

| 字段 | 类型 | 说明 |
|------|------|------|
| userId | string | 用户ID |
| username | string | 用户名 |
| nickname | string | 昵称 |
| email | string | 邮箱 |
| avatar | string | 头像 |
| roles | array | 角色列表 |
| lastLoginTime | string | 最近登录时间 |
| createTime | string | 创建时间 |

**roles item 结构**:

| 字段 | 类型 | 说明 |
|------|------|------|
| roleId | string | 角色ID |
| name | string | 角色名称 |

**响应示例**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "list": [
      {
        "userId": "USR-0001",
        "username": "admin",
        "nickname": "管理员",
        "email": "admin@liaogang.com",
        "avatar": "https://example.com/avatar/1.png",
        "roles": [
          { "roleId": "ROLE-0001", "name": "系统管理员" }
        ],
        "lastLoginTime": "2024-06-14 10:00:00",
        "createTime": "2024-01-01 09:00:00"
      }
    ],
    "pagination": {
      "page": 1,
      "size": 5,
      "total": 15,
      "totalPages": 3
    }
  },
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

### 分配角色给用户

**接口路径**: `POST /user/{userId}/roles`

**功能描述**: 分配角色给用户

**路径参数**:

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| userId | long | ✅ | 用户ID |

**请求参数** (application/json):

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| roleIds | array | ✅ | 角色ID列表 |

**请求示例**:
```json
{
  "roleIds": ["ROLE-0002", "ROLE-0003"]
}
```

**响应示例**:
```json
{
  "code": 200,
  "message": "角色分配成功",
  "data": null,
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

## 十、审计日志

### 获取审计日志列表

**接口路径**: `GET /audit-logs`

**功能描述**: 获取审计日志列表（支持筛选、分页）

**请求参数** (Query):

| 字段 | 类型 | 必填 | 说明 | 默认值 |
|------|------|------|------|--------|
| page | int | ❌ | 页码 | 1 |
| size | int | ❌ | 每页条数 | 10 |
| operateType | string | ❌ | 操作类型 | - |
| operatorId | long | ❌ | 操作人ID | - |
| startDate | string | ❌ | 开始日期 | - |
| endDate | string | ❌ | 结束日期 | - |

**operateType 枚举值**:

| 值 | 说明 |
|------|------|
| CREATE | 创建 |
| UPDATE | 更新 |
| DELETE | 删除 |
| PUBLISH | 发布 |
| AUDIT | 审核 |
| APPROVE | 批准 |
| REJECT | 驳回 |
| SUBMIT_REVIEW | 提交审核 |
| CONFLICT_DISPOSE | 冲突处置 |
| ROLE_ASSIGN | 角色分配 |

**响应参数**:

| 字段 | 类型 | 说明 |
|------|------|------|
| list | array | 日志列表 |
| pagination | object | 分页信息 |

**list item 结构**:

| 字段 | 类型 | 说明 |
|------|------|------|
| auditId | string | 审计ID |
| operateType | string | 操作类型 |
| operator | object | 操作人 |
| targetType | string | 目标类型 |
| targetId | string | 目标ID |
| beforeContent | object | 变更前内容 |
| afterContent | object | 变更后内容 |
| operateTime | string | 操作时间 |

**operator 结构**:

| 字段 | 类型 | 说明 |
|------|------|------|
| userId | string | 用户ID |
| username | string | 用户名 |
| nickname | string | 昵称 |

**响应示例**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "list": [
      {
        "auditId": "AUDIT-20260614-000001",
        "operateType": "UPDATE",
        "operator": {
          "userId": "USR-0001",
          "username": "admin",
          "nickname": "管理员"
        },
        "targetType": "KO",
        "targetId": "KO-CON-0015",
        "beforeContent": {
          "title": "岸桥最大作业量约束",
          "currentValue": "35"
        },
        "afterContent": {
          "title": "岸桥最大作业量约束",
          "currentValue": "40"
        },
        "operateTime": "2024-06-14 10:30:00"
      }
    ],
    "pagination": {
      "page": 1,
      "size": 10,
      "total": 1520,
      "totalPages": 152
    }
  },
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

### 获取审计日志详情

**接口路径**: `GET /audit-log/{auditId}`

**功能描述**: 获取审计日志详情

**路径参数**:

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| auditId | string | ✅ | 审计ID |

**响应参数**: 同列表项结构

**响应示例**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "auditId": "AUDIT-20260614-000001",
    "operateType": "UPDATE",
    "operator": {
      "userId": "USR-0001",
      "username": "admin",
      "nickname": "管理员"
    },
    "targetType": "KO",
    "targetId": "KO-CON-0015",
    "beforeContent": {
      "title": "岸桥最大作业量约束",
      "version": "v1.2.0",
      "currentValue": "35"
    },
    "afterContent": {
      "title": "岸桥最大作业量约束",
      "version": "v1.3.0",
      "currentValue": "40"
    },
    "operateTime": "2024-06-14 10:30:00"
  },
  "timestamp": 1718000000000,
  "requestId": "req-uuid-123"
}
```

---

## 接口统计汇总

| 模块 | 接口数量 |
|------|----------|
| 认证与用户 | 2 |
| 总览仪表盘 | 2 |
| 知识对象库 | 9 |
| 文档预览 | 1 |
| 提示词 | 7 |
| 知识治理 | 3 |
| 项目管理 | 9 |
| 字典管理 | 4 |
| 权限与角色 | 6 |
| 审计日志 | 2 |
| **合计** | **45** |

---

## 附录：错误码对照表

### 认证模块 (1xxx)

| code | message | 说明 |
|------|---------|------|
| 1001 | token已过期 | - |
| 1002 | refreshToken无效 | - |
| 1003 | 用户名或密码错误 | - |
| 1004 | 账号已被禁用 | - |
| 1005 | 无权限访问 | - |

### 用户模块 (2xxx)

| code | message | 说明 |
|------|---------|------|
| 2001 | 用户不存在 | - |
| 2002 | 用户名已存在 | - |

### 知识对象模块 (3xxx)

| code | message | 说明 |
|------|---------|------|
| 3001 | 知识对象不存在 | - |
| 3002 | 无编辑权限 | - |
| 3003 | 状态变更失败 | - |
| 3004 | 审核不通过 | - |
| 3005 | 该文章下存在评论，无法删除 | - |

### 提示词模块 (4xxx)

| code | message | 说明 |
|------|---------|------|
| 4001 | 提示词不存在 | - |
| 4002 | 渲染失败 | - |
| 4003 | 快照不存在 | - |

### 项目模块 (5xxx)

| code | message | 说明 |
|------|---------|------|
| 5001 | 项目不存在 | - |
| 5002 | 项目名称已存在 | - |
| 5003 | 成员不存在 | - |

### 字典模块 (6xxx)

| code | message | 说明 |
|------|---------|------|
| 6001 | 字典项不存在 | - |
| 6002 | 字典项已存在 | - |

### 角色模块 (7xxx)

| code | message | 说明 |
|------|---------|------|
| 7001 | 角色不存在 | - |
| 7002 | 角色已存在 | - |
| 7003 | 预置角色不可删除 | - |

### 治理模块 (8xxx)

| code | message | 说明 |
|------|---------|------|
| 8001 | 冲突不存在 | - |
| 8002 | 治理项不存在 | - |

### 系统模块 (9xxx)

| code | message | 说明 |
|------|---------|------|
| 9001 | 服务器内部错误 | - |
| 9002 | 参数校验失败 | - |
| 9003 | 文件不存在或已过期 | - |
| 9004 | 请求过于频繁 | - |

---

*文档结束*