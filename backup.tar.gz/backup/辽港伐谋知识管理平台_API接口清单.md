# 辽港伐谋知识管理平台 - API接口清单

> **文档编号**：API-2026-001
> **状态**：草稿
> **基于**：PRD-2026-001 v0.20 + 原型 V3.0
> **架构模式**：前后端分离（RESTful API）
> **最后更新**：2026-06-15
> **接口数量**：38个（MVP一期）

---

## 一、认证与用户

| 接口名称 | 功能说明 | PRD对应项 |
|----------|----------|-----------|
| `POST /auth/login` | 用户登录/SSO认证 | NFR-12 |
| `GET /auth/current-user` | 获取当前用户信息及菜单权限 | NFR-12, NFR-13 |

---

## 二、总览仪表盘

| 接口名称 | 功能说明 | PRD对应项 |
|----------|----------|-----------|
| `GET /dashboard/stats` | 获取统计数据（KO总数、已生效数、待治理项） | FR-01 / US-01 |
| `GET /dashboard/activities` | 获取最近10条知识对象活动动态 | FR-02 / US-02 |

---

## 三、知识对象库

| 接口名称 | 功能说明 | PRD对应项 |
|----------|----------|-----------|
| `GET /ko/library` | 获取KO全景概览（6类型入口卡片、统计数据） | FR-05 / US-03 |
| `GET /ko/{type}/list` | 获取KO列表（支持分页、筛选、搜索） | FR-07 / US-03, US-10 |
| `GET /ko/{koId}` | 获取KO详情 | FR-08 / US-04 |
| `POST /ko` | 创建知识对象 | FR-10 / US-08, US-10, US-11 |
| `PUT /ko/{koId}` | 编辑知识对象 | FR-10 / US-08, US-10, US-11 |
| `POST /ko/{koId}/submit-review` | 提交KO审核 | FR-11 / US-08 |
| `POST /ko/{koId}/approve` | 审核通过 | FR-11 / US-08, US-14 |
| `POST /ko/{koId}/reject` | 审核驳回（需填写理由） | FR-11 / US-08, US-14 |

---

## 四、文档预览

| 接口名称 | 功能说明 | PRD对应项 |
|----------|----------|-----------|
| `GET /ko/doc/{koId}/file` | 获取文档文件（预览/下载） | FR-38 / US-03 |

---

## 五、提示词

| 接口名称 | 功能说明 | PRD对应项 |
|----------|----------|-----------|
| `GET /prompts` | 获取提示词列表 | FR-12 / US-05, US-07 |
| `GET /prompts/{promptId}` | 获取提示词详情（含选中的KO） | FR-12 / US-05, US-07 |
| `POST /prompt` | 新建提示词 | FR-12 / US-05 |
| `PUT /prompt/{promptId}` | 编辑提示词（包含KO选择） | FR-12 / US-05, FR-14 |
| `POST /prompt/{promptId}/render` | 渲染提示词（含预检） | FR-16 / US-06, FR-18 |
| `GET /prompt/{promptId}/snapshots` | 获取版本快照历史 | FR-19 / US-07 |
| `POST /prompt/{promptId}/snapshot` | 创建快照 | FR-20 / US-07 |

---

## 六、知识治理

| 接口名称 | 功能说明 | PRD对应项 |
|----------|----------|-----------|
| `GET /governance/conflicts` | 获取C类对象间冲突列表 | FR-21 / US-06 |
| `GET /governance/health-issues` | 获取H类自身健康问题列表 | FR-22 / US-06 |
| `POST /governance/conflict/{conflictId}/dispose` | 处置冲突 | FR-23 / US-06 |

---

## 七、项目管理

| 接口名称 | 功能说明 | PRD对应项 |
|----------|----------|-----------|
| `GET /projects` | 获取项目列表 | FR-30 / US-15 |
| `POST /project` | 创建项目 | FR-31 / US-15 |
| `PUT /project/{projectId}` | 编辑项目信息 | FR-31 / US-15 |
| `GET /project/{projectId}` | 获取项目详情 | FR-31 / US-15 |
| `POST /project/{projectId}/archive` | 归档项目 | FR-34 / US-15 |
| `GET /project/{projectId}/members` | 获取项目成员列表 | FR-32 / US-16 |
| `POST /project/{projectId}/member` | 添加项目成员 | FR-32 / US-16 |
| `PUT /project/{projectId}/member/{userId}` | 修改成员角色 | FR-32 / US-16 |
| `DELETE /project/{projectId}/member/{userId}` | 移除项目成员 | FR-32 / US-16 |

---

## 八、字典管理

| 接口名称 | 功能说明 | PRD对应项 |
|----------|----------|-----------|
| `GET /dictionary` | 获取字典列表（支持type参数筛选） | FR-29 / US-19 |
| `PUT /dictionary/{dictId}` | 编辑字典项 | FR-29 / US-19 |
| `POST /dictionary` | 新增字典项（类型分组、量纲） | FR-29 / US-19 |
| `DELETE /dictionary/{dictId}` | 删除字典项 | FR-29 / US-19 |

---

## 九、权限与角色

| 接口名称 | 功能说明 | PRD对应项 |
|----------|----------|-----------|
| `GET /roles` | 获取角色列表 | FR-27 / US-17 |
| `POST /role` | 创建角色 | FR-27 / US-17 |
| `PUT /role/{roleId}` | 编辑角色 | FR-27 / US-17 |
| `DELETE /role/{roleId}` | 删除角色 | FR-27 / US-17 |
| `GET /users` | 获取平台用户列表 | FR-28 / US-18 |
| `POST /user/{userId}/roles` | 分配角色给用户 | FR-28 / US-18 |

---

## 十、审计日志

| 接口名称 | 功能说明 | PRD对应项 |
|----------|----------|-----------|
| `GET /audit-logs` | 获取审计日志列表（支持筛选、分页） | FR-26 / US-20 |
| `GET /audit-log/{auditId}` | 获取审计日志详情 | FR-26 / US-20 |

---

## 接口统计汇总

| 模块 | 接口数量 |
|------|----------|
| 认证与用户 | 2 |
| 总览仪表盘 | 2 |
| 知识对象库 | 9 |
| 文档预览 | 1 |
| 提示词 | 7 |
| 知识治理 | 3 |
| 项目管理 | 9 |
| 字典管理 | 4 |
| 权限与角色 | 6 |
| 审计日志 | 2 |
| **合计** | **45** |

---

## 附录A：简化说明

### 已删除的接口（35个）

| 模块 | 删除接口 | 删除原因 |
|------|----------|----------|
| KO库 | `GET /ko/types/{type}` | 类型详情合并到列表接口返回 |
| KO库 | `GET /ko/search/cross-type` | 跨类搜索作为列表筛选参数实现 |
| KO库 | `GET /ko/{type}/conflicts` | 冲突信息在KO详情中返回 |
| KO库 | `POST /ko/batch-import` | MVP砍掉批量导入功能 |
| KO库 | `GET /ko/{type}/import-template` | MVP砍掉导入模板下载 |
| 文档 | `GET /ko/doc/{koId}/preview-url` | 合并到file接口 |
| 提示词 | `GET /prompt/composer/ko-selector` | KO选择器数据从详情接口获取 |
| 提示词 | `POST /prompt/{promptId}/ko-select` | 选KO在保存提示词时一起处理 |
| 提示词 | `POST /prompt/{promptId}/precheck` | 预检作为渲染的子步骤 |
| 提示词 | `GET /prompt/{promptId}/render-preview` | 预览与渲染合并 |
| 提示词 | `POST /prompt/{promptId}/export` | MVP砍掉导出功能 |
| 提示词 | `GET /snapshot/{snapshotId}/compare/{otherSnapshotId}` | MVP砍掉快照对比 |
| 治理 | `GET /governance/stats` | 统计信息合并到列表接口返回 |
| 治理 | `POST /governance/batch-dispose` | MVP砍掉批量处置 |
| 治理 | `POST /governance/scan` | MVP砍掉LLM全库扫描 |
| 治理 | `GET /governance/report/export` | MVP砍掉导出治理报告 |
| 字典 | `GET /dictionary/types` 等 | 合并为通用字典接口 |
| 字典 | `PUT /dictionary/type/{typeCode}` 等 | 合并为通用字典接口 |
| 用户 | `GET /user/{userId}/roles` | 获取用户角色从用户列表返回 |
| 通知 | `GET /notifications` | 本期不实现通知功能 |
| 通知 | `PUT /notification/{notificationId}/read` | 本期不实现通知功能 |

### 接口合并说明

1. **文档预览**：`preview-url` + `download` → `file`
2. **提示词渲染**：渲染 + 预检 + 预览 → `render` 一个接口
3. **字典管理**：每类字典CRUD → 通用 `GET/POST/PUT/DELETE /dictionary`
4. **用户角色**：单独获取角色接口 → 用户列表中返回当前角色

---

## 附录B：PRD需求编号索引

| 需求编号 | 需求名称 | 对应接口 |
|----------|----------|----------|
| FR-01 | 统计卡片展示 | `GET /dashboard/stats` |
| FR-02 | 最近活动列表 | `GET /dashboard/activities` |
| FR-05 | 全景概览首页 | `GET /ko/library` |
| FR-07 | KO列表表格 | `GET /ko/{type}/list` |
| FR-08 | KO详情展示 | `GET /ko/{koId}` |
| FR-10 | KO创建与编辑 | `POST /ko`, `PUT /ko/{koId}` |
| FR-11 | KO审核与生命周期管理 | `POST /ko/{koId}/submit-review`, `approve`, `reject` |
| FR-12 | 提示词列表页 | `GET /prompts`, `POST /prompt`, `PUT /prompt/{promptId}` |
| FR-14 | KO选择与编排 | `PUT /prompt/{promptId}` (内含KO选择) |
| FR-16 | 组装预检面板 | `POST /prompt/{promptId}/render` |
| FR-18 | 提示词导出与快照 | `POST /prompt/{promptId}/render`, `snapshot` |
| FR-19 | 版本时间线 | `GET /prompt/{promptId}/snapshots` |
| FR-20 | 快照创建与管理 | `POST /prompt/{promptId}/snapshot` |
| FR-21 | C类对象间冲突管理 | `GET /governance/conflicts` |
| FR-22 | H类自身健康管理 | `GET /governance/health-issues` |
| FR-23 | 治理操作功能 | `POST /governance/conflict/{conflictId}/dispose` |
| FR-26 | 审计日志 | `GET /audit-logs`, `GET /audit-log/{auditId}` |
| FR-27 | 角色创建与管理 | `GET /roles`, `POST /role`, `PUT /role/{roleId}`, `DELETE /role/{roleId}` |
| FR-28 | 用户角色分配 | `GET /users`, `POST /user/{userId}/roles` |
| FR-29 | 字典管理 | `GET /dictionary`, `PUT /dictionary/{dictId}`, `POST /dictionary`, `DELETE /dictionary/{dictId}` |
| FR-30 | 项目列表页 | `GET /projects` |
| FR-31 | 项目创建与编辑 | `POST /project`, `PUT /project/{projectId}` |
| FR-32 | 项目成员管理 | `GET /project/{projectId}/members`, `POST /member`, `PUT /member/{userId}`, `DELETE /member/{userId}` |
| FR-34 | 项目归档 | `POST /project/{projectId}/archive` |
| FR-38 | 文档预览 | `GET /ko/doc/{koId}/file` |
| NFR-12 | 用户认证 | `POST /auth/login`, `GET /auth/current-user` |
| NFR-13 | 权限控制 | `GET /auth/current-user` |

---

*文档结束*